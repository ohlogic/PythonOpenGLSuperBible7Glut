#!/usr/bin/python3

from ktxloader import KTXObject    # location of ktx file format loader

try:
    from OpenGL.GLUT import *
    from OpenGL.GL import *
    from OpenGL.GLU import *
    from OpenGL.raw.GL.ARB.vertex_array_object import glGenVertexArrays, glBindVertexArray
except:
    print ('''
    ERROR: PyOpenGL not installed properly.
        ''')
    sys.exit()
    
ktxobject = KTXObject()

class OVERLAY_():

    def __init__(self):
        self.dirty = False
        self.vao = GLuint(0)
        
        self.screen_buffer = []
        
    def print(self, str1):

        i = str(''.join(self.screen_buffer)).find('\0')
        for x in range(0, len(str1)):
            self.screen_buffer[i+x] = str1[x]

        self.dirty = True

    def drawText(self, str1, x, y):
    
        z = x + (y* self.buffer_width)
    
        for x in range(0, len(str1)):
            self.screen_buffer[z+x] = str1[x]
            
        self.dirty = True
        

    def moveCursor(self, x, y):
        self.cursor_x = x
        self.cursor_y = y
    
    def clear(self):
        
        self.screen_buffer = ['\0' for _ in range(self.buffer_width * self.buffer_height)]
        
        self.dirty = True
        self.cursor_x = 0
        self.cursor_y = 0
    
    
    def draw(self):
    
        glUseProgram(self.text_program)
        glActiveTexture(GL_TEXTURE0)
        glBindTexture(GL_TEXTURE_2D, self.text_buffer)
        
        if (self.dirty):
        
            glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, self.buffer_width, self.buffer_height, GL_RED_INTEGER, GL_UNSIGNED_BYTE, str(''.join(self.screen_buffer)))
            dirty = False;
        
        glActiveTexture(GL_TEXTURE1)
        glBindTexture(GL_TEXTURE_2D_ARRAY, self.font_texture)

        glBindVertexArray(self.vao)
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4)

    
    
    def init(self, width, height, font=''):

        vs = GLuint(0)
        fs = GLuint(0)

        self.buffer_width = width
        self.buffer_height = height

        vs = glCreateShader(GL_VERTEX_SHADER)
        fs = glCreateShader(GL_FRAGMENT_SHADER)

        vs_source = '''
#version 440 core
void main(void)
{
    gl_Position = vec4(float((gl_VertexID >> 1) & 1) * 2.0 - 1.0,
                       float((gl_VertexID & 1)) * 2.0 - 1.0,
                       0.0, 1.0);
}
'''

        fs_source = '''
#version 440 core
layout (origin_upper_left) in vec4 gl_FragCoord;
layout (location = 0) out vec4 o_color;
layout (binding = 0) uniform isampler2D text_buffer;
layout (binding = 1) uniform isampler2DArray font_texture;
void main(void)
{
    ivec2 frag_coord = ivec2(gl_FragCoord.xy);
    ivec2 char_size = textureSize(font_texture, 0).xy;
    ivec2 char_location = frag_coord / char_size;
    ivec2 texel_coord = frag_coord % char_size;
    int character = texelFetch(text_buffer, char_location, 0).x;
    float val = texelFetch(font_texture, ivec3(texel_coord, character), 0).x;
    if (val == 0.0)
        discard;
    o_color = vec4(1.0);
}
'''
        glShaderSource(vs, vs_source)
        glCompileShader(vs)

        glShaderSource(fs, fs_source)
        glCompileShader(fs)

        self.text_program = glCreateProgram()
        glAttachShader(self.text_program, vs)
        glAttachShader(self.text_program, fs)
        glLinkProgram(self.text_program)

        glDeleteShader(fs)
        glDeleteShader(vs)

        # glCreateVertexArrays(1, &vao);
        glGenVertexArrays(1, self.vao)
        glBindVertexArray(self.vao)

        # glCreateTextures(GL_TEXTURE_2D, 1, &text_buffer);
        self.text_buffer = glGenTextures(1)
        glBindTexture(GL_TEXTURE_2D, self.text_buffer)
        glTexStorage2D(GL_TEXTURE_2D, 1, GL_R8UI, width, height)
        
        if (font  == ''):
            font = "cp437_9x16.ktx"
        
        self.font_texture = ktxobject.ktx_load(font)

        self.screen_buffer = ['\0' for _ in range(width * height)]
            